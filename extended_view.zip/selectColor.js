//トップレベルのスクリプト。アプリじゃなくて、KINTONEのトップレベルに入れる事
//Customizing Kintone System-Wide
selectColor = {
  "営業 (訪問)": "gray",
    "営業 (Web)": "silver",
    "社員面談 (訪問)": "lightcoral",
    "社員面談 (Web)": "blue",
    "面接": "navy",
    "説明会": "teal",
    "社内会議": "lightseagreen",
    "業者打合せ": "lime",
    "来客": "aqua",
    "出張": "yellow",
    "配属": "lightpink",
    "在宅": "fuchsia",
    "有給休暇": "olive",
    "その他": "purple",
};
